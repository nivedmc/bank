import React from 'react';
import { render, screen, act } from '@testing-library/react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import ProtectedRoute from './protectedroute';

describe('ProtectedRoute component', () => {
  it('renders children when user is logged in', () => {
    // Mock localStorage
    const mockLocalStorage = {
      getItem: jest.fn(() => 'mockAccessToken'), // Assuming a mock access token is present
    };
    Object.defineProperty(window, 'localStorage', { value: mockLocalStorage });

    render(
      <Router>
        <ProtectedRoute>
          <div data-testid="protected-content">Protected Content</div>
        </ProtectedRoute>
      </Router>
    );

    expect(screen.getByTestId('protected-content')).toBeInTheDocument();
  });

  it('redirects to login when user is not logged in', async () => {
    // Mock localStorage
    const mockLocalStorage = {
      getItem: jest.fn(() => null), // Assuming no access token is present
    };
    Object.defineProperty(window, 'localStorage', { value: mockLocalStorage });

    // Mock the useNavigate hook
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({
      ...jest.requireActual('react-router-dom'),
      useNavigate: () => mockNavigate,
    }));

    render(
      <Router>
        <ProtectedRoute>
          <div data-testid="protected-content">Protected Content</div>
        </ProtectedRoute>
      </Router>
    );

    // Ensure that useNavigate is called to redirect to the login page
    // expect(mockNavigate).toHaveBeenCalledWith('/login');
  });
});
