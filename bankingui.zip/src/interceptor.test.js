import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import { axiosPrivate } from './yourAxiosModule'; // Adjust the import path

describe('axiosPrivate Interceptors', () => {
  let mock;

  beforeEach(() => {
    mock = new MockAdapter(axios);
  });

  afterEach(() => {
    mock.restore();
  });

  it('sets Authorization header with token for requests', async () => {
    // Arrange
    const token = 'your_test_token';
    localStorage.setItem('token', token);

    // Mock the API request
    mock.onAny().reply((config) => {
      // Assert that the Authorization header is set with the correct token
      expect(config.headers['Authorization']).toBe(`Bearer ${token}`);
      return [200, {}]; // Respond with a dummy successful response
    });

    // Act
    await axiosPrivate.get('/test');

    // Assert (axios interceptors are asynchronous, so you may need to use async/await or return the promise)
  });
});
