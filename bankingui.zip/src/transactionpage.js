import { useState } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import BankNavbar from './bank_nav';
import axios from 'axios';
import { customerService } from './apiurls';
import FloatingLabel from 'react-bootstrap/FloatingLabel';

function Transactionpage() {
  const [submitted, setSubmitted] = useState(false);
  const [amount, setAmount] = useState(0);
  const [transactionType, setTransactionType] = useState('deposit');

  const handleTransaction = async (e) => {
    e.preventDefault();

    try {
      const data = {amount: amount,transaction_type: transactionType}
      // const axiosInstance = axios.create({
      //   baseURL: 'http://127.0.0.1:8000/api/transactions/',
      //   headers: {
      //     Authorization: `Bearer ${localStorage.getItem('token')}`
      //   }
      // });
  
      const response = await customerService.transaction(data);

      console.log('Transaction successful:', response.data);
      setSubmitted(true);
      // Add logic to handle success, e.g., display a success message to the user
    } catch (error) {
      console.error('Transaction failed:', error);
      console.log()
      // Handle error scenario, e.g., show an error message to the user
    }
  };

  return (
    <div>
      <BankNavbar />
      <Container className="d-flex flex-column justify-content-center align-items-center text-center" style={{ minHeight: '100vh' }}>
        <h1>User Dashboard</h1>
        <Form style={{ width: '300px' }} onSubmit={handleTransaction}>
          <Form.Group as={Row} className="mb-3">
            <FloatingLabel controlId="floatingInput"  label="amount" className="mb-3">

            <Form.Control
           type="number"
            name="amount" 
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              </FloatingLabel>

          </Form.Group>
          <Form.Group as={Row} className="mb-3">
          <FloatingLabel controlId="floatingInput"  label="transactionType" className="mb-3">
              <Form.Select
                value={transactionType}
                onChange={(e) => setTransactionType(e.target.value)}
              >
                <option value="deposit">Deposit</option>
                <option value="withdrawal">Withdrawal</option>
              </Form.Select>
              </FloatingLabel>
          </Form.Group>
          {submitted ? (
          <div>transaction completed!</div>
        ) : (
          <Button variant="primary" type="submit" className="w-100">
            Confirm Transaction
          </Button>)}
        </Form>
      </Container>
    </div>
  );
}

export default Transactionpage;
